Este diretorio inclui o assembler para o projeto.

As instruções para o assembler estão disponiveis no PDF no diretorio principal do projeto.

No diretorio "codigos exemplo" há exemplos programas em assembly aceitos pelo assembler. 
